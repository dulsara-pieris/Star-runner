git add .
git commit -m "Game"
git push -u origin main